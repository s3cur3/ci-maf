<?php

if(!defined('CI_THEME_BUY_URL')) define('CI_THEME_BUY_URL', 'http://conversioninsights.net/modern-accounting-firm-premium/');


