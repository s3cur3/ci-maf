<?php
/*
Template Name: Blog
*/
?>

<!-- template-blog.php -->
<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'blog'); ?>
