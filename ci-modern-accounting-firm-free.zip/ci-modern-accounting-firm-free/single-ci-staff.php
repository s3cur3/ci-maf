<!-- SINGLE STAFF MEMBER -->
<?php get_template_part('templates/page', 'header-staff-member'); ?>
<?php get_template_part('templates/content', 'staff-member'); ?>
